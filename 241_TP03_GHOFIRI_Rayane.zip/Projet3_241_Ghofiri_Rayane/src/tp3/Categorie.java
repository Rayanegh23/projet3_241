package tp3;

/**
 * Enumération pour les catégories d'items du menu
 * @author rayane gh 
 */
public enum Categorie {
    ENTREE("Entrée"),
    REPAS("Repas principal"),
    DESSERT("Dessert");
    
    private String nomAffichage;
    
    private Categorie(String nomAffichage) {
        this.nomAffichage = nomAffichage;
    }
    
    @Override
    public String toString() {
        return nomAffichage;
    }
}
