package tp3;


/**
 *
 * @author Ghofiri Rayane
 */
public class Dessert extends Item {
    private boolean sansSucre;
   
    public Dessert(String nom, double prix, int calories, boolean sansSucre) {
        super(nom, prix, calories, Categorie.DESSERT);
        this.sansSucre = sansSucre;
    }
    
    // Getter et setter
    public boolean estSansSucre() {
        return sansSucre;
    }
    
    public void setSansSucre(boolean sansSucre) {
        this.sansSucre = sansSucre;
    }
    
    /**
     * Retourne les détails  du dessert
     * @return String  si c'est sans sucre ou non
     */
    @Override
    public String getDetailsSpecifiques() {
        return sansSucre ? "Sans sucre" : "Avec sucre";
    }
    
    /**
     * Représentation textuelle complète du dessert
     * @return String formaté avec toutes les informations
     */
    @Override
    public String toString() {
        return super.toString() + " - " + getDetailsSpecifiques();
    }
    
    /**
     * Vérifie l'égalité avec un autre objet
     * @param obj L'objet à comparer
     * @return vrai si les objets sont égaux
     */
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof Dessert)) return false;
        Dessert other = (Dessert) obj;
        return sansSucre == other.sansSucre;
    }
    
    /**
     * Génère un hashcode pour le dessert
     * @return int représentant le hashcode
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + (sansSucre ? 1231 : 1237);
        return result;
    }
    
    /**
     * Crée une copie du dessert
     * @return Une copie de l'objet Dessert
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
