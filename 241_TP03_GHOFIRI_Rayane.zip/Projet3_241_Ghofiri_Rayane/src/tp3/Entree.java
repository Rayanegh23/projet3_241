package tp3;

/**
 * Classe représentant une entrée du menu
 * Hérite de Item et implémente les fonctionnalités spécifiques aux entrées
 * @author Rayane Gh 
 */
public class Entree extends Item {
    private boolean estVegetarien;
    
    /**
     * Constructeur complet
     * @param nom Le nom de l'entrée
     * @param prix Le prix en dollars
     * @param calories Le nombre de calories
     * @param estVegetarien Vrai si l'entrée est végétarienne
     */
    public Entree(String nom, double prix, int calories, boolean estVegetarien) {
        super(nom, prix, calories, Categorie.ENTREE);
        this.estVegetarien = estVegetarien;
    }
    
    // Getter et setter
    public boolean estVegetarien() {
        return estVegetarien;
    }
    
    public void setVegetarien(boolean estVegetarien) {
        this.estVegetarien = estVegetarien;
    }
    
    /**
     * Retourne les détails spécifiques de l'entrée
     * @return String décrivant si c'est végétarien ou non
     */
    @Override
    public String getDetailsSpecifiques() {
        return estVegetarien ? "Végétarien" : "Non végétarien";
    }
    
    /**
     * Représentation textuelle complète de l'entrée
     * @return String formaté avec toutes les informations
     */
    @Override
    public String toString() {
        return super.toString() + " - " + getDetailsSpecifiques();
    }
    
    /**
     * Vérifie l'égalité avec un autre objet
     * @param obj L'objet à comparer
     * @return vrai si les objets sont égaux
     */
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof Entree)) return false;
        Entree other = (Entree) obj;
        return estVegetarien == other.estVegetarien;
    }
    
    /**
     * Genere un hashcode pour l'entrée
     * @return int représentant le hashcode
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + (estVegetarien ? 1231 : 1237);
        return result;
    }
    
    /**
     * Crée une copie de l'entrée
     * @return Une copie de l'objet Entree
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}