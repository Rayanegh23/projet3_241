package tp3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;

public class FenetrePrincipale extends JFrame {
    private ArrayList<Item> menu = new ArrayList<>();
    private JTextArea textArea;
    private JComboBox<Categorie> comboType;
    
    // Composants communs
    private JTextField txtNom = new JTextField(15);
    private JTextField txtPrix = new JTextField(15);
    private JTextField txtCalories = new JTextField(15);
    
    // Composants spécifiques
    private JCheckBox chkVegetarien = new JCheckBox("Végétarien");
    private JCheckBox chkAPartager = new JCheckBox("À partager");
    private JTextField txtAccompagnements = new JTextField(15);
    private JCheckBox chkSansSucre = new JCheckBox("Sans sucre");
    private JTextField txtPosition = new JTextField(5);
    
    // Panneau pour les composants spécifiques
    private JPanel panelSpecifique = new JPanel();

    public FenetrePrincipale() {
        super("Menu Restaurant Ahuntsic Ghofiri Rayane ");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        
        initUI();
    }

    private void initUI() {
        // Layout principal
        setLayout(new BorderLayout(10, 10));

        // Partie GAUCHE - Formulaire
        JPanel panelGauche = new JPanel();
        panelGauche.setLayout(new BoxLayout(panelGauche, BoxLayout.Y_AXIS));
        panelGauche.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 1. Sélection du type
        comboType = new JComboBox<>(Categorie.values());
        comboType.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        comboType.addActionListener(e -> updateForm());
        panelGauche.add(comboType);
        panelGauche.add(Box.createRigidArea(new Dimension(0, 10)));

        // 2. Champs communs
        panelGauche.add(createFieldPanel(" Description:", txtNom));
        panelGauche.add(Box.createRigidArea(new Dimension(0, 5)));
        panelGauche.add(createFieldPanel("Prix ($):", txtPrix));
        panelGauche.add(Box.createRigidArea(new Dimension(0, 5)));
        panelGauche.add(createFieldPanel("Calories:", txtCalories));
        panelGauche.add(Box.createRigidArea(new Dimension(0, 10)));

        // 3. Panneau spécifique
        panelSpecifique.setLayout(new BoxLayout(panelSpecifique, BoxLayout.Y_AXIS));
        panelGauche.add(panelSpecifique);
        panelGauche.add(Box.createRigidArea(new Dimension(0, 10)));

        // 4. Boutons principaux
        panelGauche.add(createButton("Ajouter", e -> ajouterItem()));
        panelGauche.add(Box.createRigidArea(new Dimension(0, 5)));
        panelGauche.add(createButton("Vider le menu", e -> viderMenu()));
        panelGauche.add(Box.createRigidArea(new Dimension(0, 15)));

        // 5. Gestion par position
        JPanel panelPos = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelPos.add(new JLabel("Position :"));
        panelPos.add(txtPosition);
        panelGauche.add(panelPos);
        panelGauche.add(Box.createRigidArea(new Dimension(0, 5)));

        // 6. Boutons d'action
        JPanel panelActions = new JPanel(new GridLayout(1, 3, 5, 5));
        panelActions.add(createButton("Dupliquer", e -> dupliquerItem()));
        panelActions.add(createButton("Effacer", e -> effacerItem()));
        panelActions.add(createButton("Modifier", e -> modifierItem()));
        panelGauche.add(panelActions);

        // Partie DROITE - Affichage
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Ajout au layout principal
        add(panelGauche, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        // Menu
        initMenuBar();

        // Initialisation
        updateForm();
    }

    private JPanel createFieldPanel(String label, JComponent field) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.add(new JLabel(label));
        panel.add(field);
        return panel;
    }

    private JButton createButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.addActionListener(listener);
        return button;
    }

    private void updateForm() {
        panelSpecifique.removeAll();

        Categorie cat = (Categorie) comboType.getSelectedItem();
        switch (cat) {
            case ENTREE:
                panelSpecifique.add(chkVegetarien);
                break;
            case REPAS:
                panelSpecifique.add(chkAPartager);
                panelSpecifique.add(createFieldPanel("Accompagnements:", txtAccompagnements));
                break;
            case DESSERT:
                panelSpecifique.add(chkSansSucre);
                break;
        }

        panelSpecifique.revalidate();
        panelSpecifique.repaint();
    }

    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // Menu Fichier
        JMenu menuFichier = new JMenu("Fichier");
        menuFichier.add(createMenuItem("Lire menu", e -> chargerMenu()));
        menuFichier.add(createMenuItem("Écrire menu", e -> sauvegarderMenu()));
        menuFichier.add(createMenuItem("Générer menu texte", e -> genererMenuTexte()));
        menuFichier.addSeparator();
        menuFichier.add(createMenuItem("Quitter", e -> System.exit(0)));
        
        // Menu Sécurité
        
     

     // 1. Création d'un champ de mot de passe masqué
     JPasswordField passwordField = new JPasswordField();
     passwordField.setEchoChar('*'); // Caractere de masquage

     // 2. Boîte de dialogue d'authentification
     int option = JOptionPane.showConfirmDialog(
         null, // Composant parent (null pour centre écran)
         passwordField, // Composant à afficher
         "Authentification", // Titre de la fenetre
         JOptionPane.OK_CANCEL_OPTION, // Boutons affichés
         JOptionPane.PLAIN_MESSAGE // Type de message
     );

     // 3. Vérification
     if (option == JOptionPane.OK_OPTION) {
         String password = new String(passwordField.getPassword());
         
         if (!Securite.verifierMotDePasse(password)) {
             JOptionPane.showMessageDialog(
                 null,
                 "Mot de passe incorrect",
                 "Erreur",
                 JOptionPane.ERROR_MESSAGE
             );
             System.exit(0); // Quitter lapplication
         }
     } else {
         System.exit(0); // Si lutilisateur annule
     }
        
        JMenu menuSecurite = new JMenu("Sécurité");
        menuSecurite.add(createMenuItem("Changer mot de passe", e -> changerMotDePasse()));
        
        menuBar.add(menuFichier);
        menuBar.add(menuSecurite);
        
        setJMenuBar(menuBar);
    }

    private JMenuItem createMenuItem(String text, ActionListener listener) {
        JMenuItem item = new JMenuItem(text);
        item.addActionListener(listener);
        return item;
    }

    // Méthodes fonctionnelles
    private void ajouterItem() {
        try {
            Categorie cat = (Categorie) comboType.getSelectedItem();
            Item item = null;
            
            switch (cat) {
                case ENTREE:
                    item = new Entree(
                        txtNom.getText(),
                        Double.parseDouble(txtPrix.getText()),
                        Integer.parseInt(txtCalories.getText()),
                        chkVegetarien.isSelected()
                    );
                    break;
                case REPAS:
                    item = new Repas(
                        txtNom.getText(),
                        Double.parseDouble(txtPrix.getText()),
                        Integer.parseInt(txtCalories.getText()),
                        chkAPartager.isSelected(),
                        txtAccompagnements.getText()
                    );
                    break;
                case DESSERT:
                    item = new Dessert(
                        txtNom.getText(),
                        Double.parseDouble(txtPrix.getText()),
                        Integer.parseInt(txtCalories.getText()),
                        chkSansSucre.isSelected()
                    );
                    break;
            }
            
            if (item != null) {
                menu.add(item);
                afficherMenu();
                viderChamps();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Veuillez entrer des valeurs valides pour le prix et les calories",
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viderChamps() {
        txtNom.setText("");
        txtPrix.setText("");
        txtCalories.setText("");
        chkVegetarien.setSelected(false);
        chkAPartager.setSelected(false);
        txtAccompagnements.setText("");
        chkSansSucre.setSelected(false);
    }

    private void viderMenu() {
        menu.clear();
        afficherMenu();
    }

    private void dupliquerItem() {
        try {
            int pos = Integer.parseInt(txtPosition.getText()) - 1;
            if (pos >= 0 && pos < menu.size()) {
                Item clone = (Item) menu.get(pos).clone();
                menu.add(clone);
                afficherMenu();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Position invalide ou erreur de duplication",
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void effacerItem() {
        try {
            int pos = Integer.parseInt(txtPosition.getText()) - 1;
            if (pos >= 0 && pos < menu.size()) {
                menu.remove(pos);
                afficherMenu();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Veuillez entrer une position valide",
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifierItem() {
        try {
            int pos = Integer.parseInt(txtPosition.getText()) - 1;
            if (pos >= 0 && pos < menu.size()) {
                new FenetreSecondaire(this, menu.get(pos)).setVisible(true);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Veuillez entrer une portion valide",
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void mettreAJourItem(Item ancien, Item nouveau) {
        int index = menu.indexOf(ancien);
        if (index != -1) {
            menu.set(index, nouveau);
            afficherMenu();
        }
    }

    private void trierEtAfficherMenu() {
        Collections.sort(menu);
        afficherMenu();
    }

    private void afficherMenu() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== MENU DU RESTAURANT ===\n\n");
        
        for (Categorie cat : Categorie.values()) {
            sb.append("--- ").append(cat).append(" ---\n");
            menu.stream()
                .filter(item -> item.getCategorie() == cat)
                .forEach(item -> sb.append(item).append("\n"));
            sb.append("\n");
        }
        
        textArea.setText(sb.toString());
    }

    private void chargerMenu() {
        menu = GestionFichiers.chargerMenu();
        afficherMenu();
        JOptionPane.showMessageDialog(this, "Menu chargé avec succès");
    }

    private void sauvegarderMenu() {
        try {
            GestionFichiers.sauvegarderMenu(menu);
            JOptionPane.showMessageDialog(this, "Menu sauvegardé avec succès");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur lors de la sauvegarde: " + e.getMessage(),
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void genererMenuTexte() {
        try {
            GestionFichiers.genererMenuTexte(menu);
            JOptionPane.showMessageDialog(this, 
                "Menu généré dans menu.txt",
                "Succès", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur lors de la génération: " + e.getMessage(),
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void changerMotDePasse() {
        String ancien = JOptionPane.showInputDialog(this, "Ancien mot de passe:");
        if (!Securite.verifierMotDePasse(ancien)) {
            JOptionPane.showMessageDialog(this, 
                "Mot de passe incorrect", 
                "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String nouveau = JOptionPane.showInputDialog(this, "Nouveau mot de passe:");
        if (nouveau == null || nouveau.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Le mot de passe ne peut être vide", 
                "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            Securite.changerMotDePasse(nouveau);
            JOptionPane.showMessageDialog(this, 
                "Mot de passe changé avec succès");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur lors du changement: " + e.getMessage(),
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                new FenetrePrincipale().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}