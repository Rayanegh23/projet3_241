package tp3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FenetreSecondaire extends JFrame {
    private final FenetrePrincipale parent;
    private final Item itemOriginal;
    
    private JTextField txtNom, txtPrix, txtCalories, txtAccompagnements;
    private JCheckBox chkOption1, chkOption2;
    
    public FenetreSecondaire(FenetrePrincipale parent, Item item) {
        super("Modifier Item");
        this.parent = parent;
        this.itemOriginal = item;
        
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(0, 2, 5, 5));
        
        initComponents();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    
    private void initComponents() {
        // Champs communs
        txtNom = new JTextField(itemOriginal.getNom());
        txtPrix = new JTextField(String.valueOf(itemOriginal.getPrix()));
        txtCalories = new JTextField(String.valueOf(itemOriginal.getCalories()));
        
        add(new JLabel("Nom:"));
        add(txtNom);
        add(new JLabel("Prix:"));
        add(txtPrix);
        add(new JLabel("Calories:"));
        add(txtCalories);
        
        // Champs spécifiques
        if (itemOriginal instanceof Entree entree) {
            chkOption1 = new JCheckBox("Végétarien", entree.estVegetarien());
            add(new JLabel("Végétarien:"));
            add(chkOption1);
        } 
        else if (itemOriginal instanceof Repas repas) {
            chkOption1 = new JCheckBox("À partager", repas.estAPartager());
            txtAccompagnements = new JTextField(repas.getAccompagnements());
            
            add(new JLabel("À partager:"));
            add(chkOption1);
            add(new JLabel("Accompagnements:"));
            add(txtAccompagnements);
        } 
        else if (itemOriginal instanceof Dessert dessert) {
            chkOption1 = new JCheckBox("Sans sucre", dessert.estSansSucre());
            add(new JLabel("Sans sucre:"));
            add(chkOption1);
        }
        
        // Bouton de mise à jour
        JButton btnMettreAJour = new JButton("Mettre à jour");
        btnMettreAJour.addActionListener(e -> mettreAJourItem());
        add(new JLabel());
        add(btnMettreAJour);
    }
    
    private void mettreAJourItem() {
        try {
            String nom = txtNom.getText();
            double prix = Double.parseDouble(txtPrix.getText());
            int calories = Integer.parseInt(txtCalories.getText());
            
            Item nouvelItem = null;
            
            if (itemOriginal instanceof Entree) {
                nouvelItem = new Entree(nom, prix, calories, chkOption1.isSelected());
            } 
            else if (itemOriginal instanceof Repas) {
                nouvelItem = new Repas(nom, prix, calories, chkOption1.isSelected(), txtAccompagnements.getText());
            } 
            else if (itemOriginal instanceof Dessert) {
                nouvelItem = new Dessert(nom, prix, calories, chkOption1.isSelected());
            }
            
            if (nouvelItem != null) {
                parent.mettreAJourItem(itemOriginal, nouvelItem);
                dispose();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Prix et calories doivent être des nombres valides", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
}
