package tp3;

import java.io.*;
import java.util.ArrayList;

/**
 
 * @author Ghofiri Rayane
 */
public class GestionFichiers {
    // Noms des fichiers
    private static final String FICHIER_MENU = "menu.bin";
    private static final String FICHIER_TEXTE = "menu.txt";
    private static final String FICHIER_SECURITE = "securite.bin";
    private static final String MOT_DE_PASSE_DEFAUT = "secret";

    /**
     * Lire le mot de passe depuis le fichier de sécurité
     * @return Le mot de passe stocker ou le mot de passe par defaut si erreur
     */
    public static String lireMotDePasse() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FICHIER_SECURITE))) {
            return (String) ois.readObject();
        } catch (FileNotFoundException e) {
            return MOT_DE_PASSE_DEFAUT;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erreur lecture mot de passe: " + e.getMessage());
            return MOT_DE_PASSE_DEFAUT;
        }
    }

    /**
     * ecrit le nouveau mot de passe dans le fichier de sécurité
     * @param motDePasse Le nouveau mot de passe à enregistrer
     * @throws IOException Si une erreur d'écriture survient
     */
    public static void ecrireMotDePasse(String motDePasse) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHIER_SECURITE))) {
            oos.writeObject(motDePasse);
        }
    }

    /**
     * Sauvegarde le menu dans un fichier bin
     * @param menu La liste des items à sauvegarder
     * @throws IOException Si une erreur d'écriture
     */
    public static void sauvegarderMenu(ArrayList<Item> menu) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHIER_MENU))) {
            oos.writeObject(menu);
        }
    }

    /**
     * Charge le menu depuis le fichier bin
     * @return La liste des items charge ou une nouvelle liste si erreur
     */
    @SuppressWarnings("unchecked")
    public static ArrayList<Item> chargerMenu() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FICHIER_MENU))) {
            return (ArrayList<Item>) ois.readObject();
        } catch (FileNotFoundException e) {
            return new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Erreur lecture menu: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /**
     * Genere un fichier texte formaté avec le menu
     * @param menu La liste des items à inclure dans le menu
     * @throws IOException Si une erreur d'écriture survient
     */
    public static void genererMenuTexte(ArrayList<Item> menu) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FICHIER_TEXTE))) {
            // En-tête du menu
            writer.println("=================================");
            writer.println("         MENU DU RESTAURANT       ");
            writer.println("=================================");
            writer.println();

            // Parcours par catégorie
            for (Categorie categorie : Categorie.values()) {
                writer.println("----- " + categorie.toString().toUpperCase() + " -----");
                
                menu.stream()
                    .filter(item -> item.getCategorie() == categorie)
                    .forEach(item -> {
                        writer.println("- " + item.getNom());
                        writer.printf("  Prix: %.2f$ | Calories: %d\n", item.getPrix(), item.getCalories());
                        writer.println("  " + item.getDetailsSpecifiques());
                        writer.println();
                    });
                
                writer.println();
            }

           
        }
    }

    /**
     * Vérifie si un fichier existe
     * @param nomFichier Le nom du fichier à vérifier
     * @return true si le fichier existe, false sinon
     */
    public static boolean fichierExiste(String nomFichier) {
        return new File(nomFichier).exists();
    }

    /**
     * Supprime un fichier existant
     * @param nomFichier Le nom du fichier à supprimer
     * @return true si la suppression a réussi, false sinon
     */
    public static boolean supprimerFichier(String nomFichier) {
        return new File(nomFichier).delete();
    }
}