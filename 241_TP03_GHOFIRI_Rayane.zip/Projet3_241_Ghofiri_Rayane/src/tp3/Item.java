package tp3;

import java.io.Serializable;

/**
 * Classe abstraite de base pour tous les items du menu
 * Implemente Serializable pour la sauvegarde, Cloneable pour la duplication
 * et Comparable pour le tri
 * @author rayane gh 
 */
public abstract class Item implements Serializable, Cloneable, Comparable<Item> {
    private String nom;
    private double prix;
    private int calories;
    private Categorie categorie;
    
    // Constante pour la sérialisation
    private static final long serialVersionUID = 1L;
    
    /**
     * Constructeur complet
     * @param nom Le nom de l'item
     * @param prix Le prix de l'item
     * @param calories Le nombre de calories
     * @param categorie La catégorie de l'item (enum)
     */
    public Item(String nom, double prix, int calories, Categorie categorie) {
        this.nom = nom;
        this.prix = prix;
        this.calories = calories;
        this.categorie = categorie;
    }
    
    // Getters et setters
    
    public String getNom() {
        return nom;
    }
    
    public void setNom(String nom) {
        this.nom = nom;
    }
    
    public double getPrix() {
        return prix;
    }
    
    public void setPrix(double prix) {
        this.prix = prix;
    }
    
    public int getCalories() {
        return calories;
    }
    
    public void setCalories(int calories) {
        this.calories = calories;
    }
    
    public Categorie getCategorie() {
        return categorie;
    }
    
    // Méthodes requi par les interfaces
    
    /**
     * Comparaison basée sur le nom pour le tri
     */
    @Override
    public int compareTo(Item autre) {
        return this.nom.compareToIgnoreCase(autre.nom);
    }
    
    /**
     * Crée une copie de l'item
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    
    /**
     * Vérifie l'égalité basée sur tous les attributs
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Item item = (Item) obj;
        return Double.compare(item.prix, prix) == 0 &&
               calories == item.calories &&
               nom.equalsIgnoreCase(item.nom) &&
               categorie == item.categorie;
    }
    
    /**
     * Génère un hashcode basé sur les attributs
     */
    @Override
    public int hashCode() {
        int result = nom != null ? nom.hashCode() : 0;
        long temp = Double.doubleToLongBits(prix);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + calories;
        result = 31 * result + (categorie != null ? categorie.hashCode() : 0);
        return result;
    }
    
    /**
     * Représentation textuelle de l'item
     */
    @Override
    public String toString() {
        return String.format("[%s] %s - %.2f$ (%d cal)", 
               categorie.toString(), nom, prix, calories);
    }
    
    /**
     * Methode pour obtenir les details specifique de l'item
     * @return Les caractéristiques specifiques sous forme de String
     */
    public abstract String getDetailsSpecifiques();
}