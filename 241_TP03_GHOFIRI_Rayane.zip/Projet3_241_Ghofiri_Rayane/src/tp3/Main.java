package tp3;

import javax.swing.*;


	public class Main {
    public static void main(String[] args) {
        // Vérifier le mot de passe
        String motDePasse = GestionFichiers.lireMotDePasse();
        String saisie = JOptionPane.showInputDialog(null, "Veuillez saisir votre mot de passe:");
        
        if (saisie == null || !saisie.equals(motDePasse)) {
            JOptionPane.showMessageDialog(null, "Mot de passe incorrect. L'application va se fermer.", 
                                         "Erreur", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
        
        // Démarrer l'application
        SwingUtilities.invokeLater(() -> {
            FenetrePrincipale fenetre = new FenetrePrincipale();
            fenetre.setVisible(true);
        });
    }
}
