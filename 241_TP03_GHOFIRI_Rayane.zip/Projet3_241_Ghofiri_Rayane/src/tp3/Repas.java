package tp3;

/**
 * Classe représentant un repas principal du menu
 * Hérite de Item et implémente les fonctionnalités spécifiques aux repas
 * @author Rayane Gh
 */
public class Repas extends Item {
    private boolean aPartager;
    private String accompagnements;
    
    /**
     * Constructeur complet
     * @param nom Le nom du repas
     * @param prix Le prix en dollars
     * @param calories Le nombre de calories
     * @param aPartager Vrai si le repas peut être partagé
     * @param accompagnements Les accompagnements du repas
     */
    public Repas(String nom, double prix, int calories, boolean aPartager, String accompagnements) {
        super(nom, prix, calories, Categorie.REPAS);
        this.aPartager = aPartager;
        this.accompagnements = accompagnements;
    }
    
    // Getters et setters
    public boolean estAPartager() {
        return aPartager;
    }
    
    public void setAPartager(boolean aPartager) {
        this.aPartager = aPartager;
    }
    
    public String getAccompagnements() {
        return accompagnements;
    }
    
    public void setAccompagnements(String accompagnements) {
        this.accompagnements = accompagnements;
    }
    
    /**
     * Retourne les détails spécifiques du repas
     * @return String décrivant si partageable et les accompagnements
     */
    @Override
    public String getDetailsSpecifiques() {
        return (aPartager ? "À partager, " : "") + "Accompagnements: " + accompagnements;
    }
    
    /**
     * Représentation textuelle complète du repas
     * @return String formaté avec toutes les informations
     */
    @Override
    public String toString() {
        return super.toString() + " - " + getDetailsSpecifiques();
    }
    
    /**
     * Vérifie l'égalité avec un autre objet
     * @param obj L'objet à comparer
     * @return vrai si les objets sont égaux
     */
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof Repas)) return false;
        Repas other = (Repas) obj;
        return aPartager == other.aPartager && 
               accompagnements.equals(other.accompagnements);
    }
    
    /**
     * Génère un hashcode pour le repas
     * @return int représentant le hashcode
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + (aPartager ? 1231 : 1237);
        result = prime * result + accompagnements.hashCode();
        return result;
    }
    
    /**
     * Crée une copie du repas
     * @return Une copie de l'objet Repas
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}