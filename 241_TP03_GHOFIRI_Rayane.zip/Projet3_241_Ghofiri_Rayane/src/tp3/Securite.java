package tp3;

import java.io.*;

import javax.swing.JOptionPane;

/**
 * Gère l'authentification et le mot de passe de l'application
 */
public class Securite {
    private static final String FICHIER_MDP = "securite.bin";
    private static final String MDP_DEFAUT = "secret";

    public static boolean verifierMotDePasse(String motDePasse) {
        return motDePasse.equals(lireMotDePasse());
    }

    public static String lireMotDePasse() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FICHIER_MDP))) {
            return (String) ois.readObject();
        } catch (Exception e) {
            return MDP_DEFAUT;
        }
    }

    public static void changerMotDePasse(String nouveauMdp) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHIER_MDP))) {
            oos.writeObject(nouveauMdp);
        }
    }

    public static boolean demanderAcces() {
        String mdp = JOptionPane.showInputDialog(null, 
            "Entrez le mot de passe:", "Authentification", JOptionPane.PLAIN_MESSAGE);
        return verifierMotDePasse(mdp);
    }
}